public interface CalculosLaborales {
    // Aqui tenemos las diferentes funciones que mas tarde usaremos y realizaremos en las clases Tecnicos , Gestor y Administrativo
    double calcularBonificacion();

    double calcularSalario();

    int calcularVacaciones();
}
